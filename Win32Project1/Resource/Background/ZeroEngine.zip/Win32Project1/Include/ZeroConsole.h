﻿#pragma once

class ZeroConsole {

public:
	ZeroConsole();
	~ZeroConsole();
};
